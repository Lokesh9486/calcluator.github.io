const calTable=document.querySelectorAll(".cal-table td");
const calTableTh=document.querySelector(".cal-table th");
const inputCal=document.querySelector(".input-cal");
const upperInput=document.querySelector(".upper-input");

calTable.forEach(item => {
    item.addEventListener("click",()=>{
      if(item.getAttribute("value")==="c"){
        inputCal.value=" ";
        upperInput.innerHTML=" ";
      }
      else if(item.getAttribute("value")==="x"){
        inputCal.value=inputCal.value.slice(0, -1);
      }
      else{
        inputCal.value+=item.getAttribute("value");
      }
    });
});

calTableTh.addEventListener("click",()=>{
  const userInput=inputCal.value;
  inputCal.value=(eval(userInput));
  upperInput.innerHTML=userInput;
})
